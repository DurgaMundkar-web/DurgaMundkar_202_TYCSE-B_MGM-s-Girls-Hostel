<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$message = "";

// ------------------- SIGNUP -------------------
if (isset($_POST['action']) && $_POST['action'] === "signup") {

    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    $year = $_POST['year'];
    $branch = $_POST['branch'];
    $college = $_POST['college'];
    $city = $_POST['city'];

    // Confirm password check
    if ($pass !== $confirm) {
        $message = "⚠️ Passwords do not match!";
    } else {

        $hashed = password_hash($pass, PASSWORD_DEFAULT);

        // Check if email exists
        $check = $conn->prepare("SELECT * FROM users WHERE email=?");
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            $message = "⚠️ Email already exists! Please login.";
        } else {

            $stmt = $conn->prepare("INSERT INTO users (fullname,email,password,year,branch,college,city)
                                    VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param("sssssss", $fullname,$email,$hashed,$year,$branch,$college,$city);

            if ($stmt->execute()) {
                $message = "✅ Signup successful! Please login.";
            } else {
                $message = "❌ Error while signing up!";
            }
        }
    }
}

// ------------------- LOGIN -------------------
if (isset($_POST['action']) && $_POST['action'] === "login") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();


        if (password_verify($password, $row['password'])) {
    $_SESSION['users_email'] = $row['email'];
    $_SESSION['users_name'] = $row['fullname'];
    header("Location: syllabus.php");
    exit();

        } else {
            $message = "❌ Invalid password!";
        }
    } else {
        $message = "⚠️ No account found!";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login / Sign Up | MathFusion</title>
    <link rel="stylesheet" href="Login.css" />
</head>
<body>
    <style>
        /* ------------------ Global ------------------ */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    background: linear-gradient(135deg, #040d1a, #081d2e, #0b2f49);
    color: #e8f9ff;
}

/* ------------------ Navbar ------------------ */
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 60px;
    background: #1a1a2e;
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 100;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
}

.logo {
    font-size: 2rem;
    font-weight: 700;
    color: #00d4ff;
    cursor: pointer;
}

.nav-links {
    list-style: none;
    display: flex;
    gap: 25px;
    margin-left: auto;
}

.nav-links li a {
    text-decoration: none;
    color: #fff;
    font-weight: 600;
    transition: 0.3s;
}

.nav-links li a:hover,
.nav-links li a.active {
    color: #00fff0;
}

/* ------------------ Auth Section ------------------ */
.auth-section {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding-top: 80px; /* space for navbar */
}

.form-box {
    background: rgba(10, 10, 25, 0.85);
    backdrop-filter: blur(12px);
    padding: 40px;
    border-radius: 20px;
    width: 400px;
    box-shadow: 0 15px 30px rgba(0,0,0,0.6);
}

.button-box {
    display: flex;
    justify-content: center;
    margin-bottom: 25px;
    gap: 10px;
}

.toggle-btn {
    padding: 10px 25px;
    border: none;
    border-radius: 25px;
    background: #1a1a2e;
    color: #fff;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}

.toggle-btn.active {
    background: #00d4ff;
    color: #0b0f14;
}

.form {
    display: none;
    flex-direction: column;
}

.form.active {
    display: flex;
}

.form h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #00d4ff;
}

.form input, .form select {
    padding: 12px;
    margin: 10px 0;
    border-radius: 10px;
    border: none;
    background: rgba(20,20,35,0.8);
    color: #e8f9ff;
    font-size: 1rem;
}

.form input::placeholder {
    color: #b0b8c1;
}

.submit-btn {
    margin-top: 15px;
    padding: 12px;
    border: none;
    border-radius: 25px;
    background: #00d4ff;
    color: #0b0f14;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}

.submit-btn:hover {
    background: #00fff0;
}

.switch-text {
    text-align: center;
    margin-top: 10px;
    font-size: 0.9rem;
}

.switch-text span {
    color: #00d4ff;
    cursor: pointer;
    font-weight: 600;
}

.switch-text span:hover {
    color: #00fff0;
}

footer {
    background: #1a1a2e;
    color: #b0b8c1;
    padding: 20px;
    text-align: center;
    margin-top: 50px;
}

@media screen and (max-width: 500px) {
    .form-box {
        width: 90%;
        padding: 25px;
    }

    .navbar {
        padding: 10px 30px;
    }

    .nav-links {
        gap: 15px;
    }
}
    </style>

    <!-- Navigation Bar -->
    <header>
        <nav class="navbar">
            <div class="logo">MathFusion</div>
            <ul class="nav-links">
                <li><a href="index.html" >Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="syllabus.php" onclick="openSyllabus()">Syllabus</a></li>
                <li><a href="rating.html">Ratings</a></li>
                <li><a href="profile.php">Student Profile</a></li>
            </ul>
        </nav>
    </header>
    
    <!-- Login & Signup Section -->
    <section class="auth-section">
        <div class="form-box">
            <div class="button-box">
                <button id="loginBtn" class="toggle-btn active" onclick="showLogin()">Login</button>
                <button id="signupBtn" class="toggle-btn" onclick="showSignup()">Sign Up</button>
            </div>

            <!-- Login Form -->
           <form id="loginForm" class="form active" method="POST" action="">
    <h2>Welcome Back 👋</h2>

    <input type="email" name="email" id="email" placeholder="Enter Email" required>
    <input type="password" name="password" id="password" placeholder="Enter Password" required>
    
    <button type="submit" name="action" value="login" class="submit-btn">Login</button>
</form>


            <!-- Signup Form -->
            <form id="signupForm" class="form" method="POST" action="">
    <h2>Create an Account 📝</h2>

    <input type="text" name="fullname" placeholder="Full Name" required>
    <input type="email" name="email" placeholder="Email Address" required>

    <input type="password" name="password" placeholder="Password" required>
    <input type="password" name="confirm_password" placeholder="Confirm Password" required>

    <select name="year" required>
        <option value="">Select Year</option>
        <option>1st Year</option>
        <option>2nd Year</option>
        <option>3rd Year</option>
        <option>4th Year</option>
    </select>

    <input type="text" name="branch" placeholder="Branch" required>
    <input type="text" name="college" placeholder="College Name" required>
    <input type="text" name="city" placeholder="City" required>

    <button type="submit" name="action" value="signup" class="submit-btn">Sign Up</button>
</form>

        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 MathFusion | All Rights Reserved</p>
    </footer>

    <!-- JavaScript -->
    <script>
        const loginForm = document.getElementById("loginForm");
        const signupForm = document.getElementById("signupForm");
        const loginBtn = document.getElementById("loginBtn");
        const signupBtn = document.getElementById("signupBtn");

        function showLogin() {
            loginForm.classList.add("active");
            signupForm.classList.remove("active");
            loginBtn.classList.add("active");
            signupBtn.classList.remove("active");
        }

        function showSignup() {
            signupForm.classList.add("active");
            loginForm.classList.remove("active");
            signupBtn.classList.add("active");
            loginBtn.classList.remove("active");
        }

        function openSyllabus(){
            <?php if(!isset($_SESSION['user'])) { ?>
                alert("Please Login First!");
            <?php } else { ?>
                window.location.href = "syllabus.php";
            <?php } ?>
        }
    </script>
</body>
</html>
