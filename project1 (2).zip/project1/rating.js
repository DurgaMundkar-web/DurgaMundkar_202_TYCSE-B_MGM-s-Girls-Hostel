// Get form and container
const reviewForm = document.getElementById("reviewForm");
const reviewsContainer = document.getElementById("reviewsContainer");

// Load existing reviews from localStorage or keep default HTML reviews
let reviews = JSON.parse(localStorage.getItem("reviews")) || [];

// Display saved reviews
function displayReviews() {
    // Remove previously dynamically added reviews
    const dynamicReviews = reviewsContainer.querySelectorAll(".dynamic-review");
    dynamicReviews.forEach(r => r.remove());

    // Add each review dynamically
    reviews.slice().reverse().forEach(r => {
        const div = document.createElement("div");
        div.classList.add("review-card", "dynamic-review");
        div.innerHTML = `
            <h4>${r.name} 😊</h4>
            <div class="stars">${"★".repeat(r.rating)}${"☆".repeat(5 - r.rating)}</div>
            <p>${r.review}</p>
        `;
        reviewsContainer.appendChild(div);
    });
}

// Handle form submission
reviewForm.addEventListener("submit", function(e) {
    e.preventDefault();
    const reviewText = document.getElementById("reviewText").value.trim();
    const name = prompt("Enter your name:") || "Anonymous";
    const rating = parseInt(document.querySelector('input[name="rating"]:checked')?.value || "5");

    if (reviewText) {
        const newReview = { name, review: reviewText, rating };
        reviews.push(newReview);
        localStorage.setItem("reviews", JSON.stringify(reviews));
        displayReviews();
        reviewForm.reset();
    } else {
        alert("Please write a review before submitting!");
    }
});

// Initialize
displayReviews();
