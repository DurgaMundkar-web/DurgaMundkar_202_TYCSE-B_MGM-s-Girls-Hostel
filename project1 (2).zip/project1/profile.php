<?php
session_start();
include 'db.php';

// If user is not logged in -> redirect to login
if (!isset($_SESSION['users_email'])) {
    header("Location: login.php");
    exit();
}

// Fetch user data from database
$email = $_SESSION['users_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Profile | MathFusion</title>

    <style>
        :root {
            --primary: #00d4ff;
            --accent: #00fff0;
            --text: #e8f9ff;
            --card: rgba(10,10,25,0.85);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins',sans-serif;
        }

        body {
            background: linear-gradient(135deg,#040d1a,#081d2e,#0b2f49);
            color: var(--text);
        }

        /* Navbar */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 60px;
            background: #1a1a2e;
            position: fixed;
            top: 0;
            width: 100%;
            box-shadow: 0 0 15px rgba(0,0,0,0.4);
            z-index: 10;
        }

        .logo {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 25px;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text);
            font-weight: 600;
            transition: 0.3s;
        }

        .nav-links a:hover,
        .nav-links .active {
            color: var(--accent);
        }

        /* Profile Container */
        .profile-container {
            display: flex;
            justify-content: center;
            padding-top: 120px;
        }

        .profile-card {
            background: var(--card);
            backdrop-filter: blur(10px);
            width: 420px;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0,255,255,0.3);
            text-align: center;
            animation: fadeIn .6s ease-out;
        }

        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(20px);}
            to {opacity: 1; transform: translateY(0);}
        }

        .profile-card img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 3px solid var(--primary);
            margin-bottom: 10px;
        }

        .profile-card h2 {
            color: var(--primary);
            margin-bottom: 5px;
        }

        .profile-card p {
            margin: 8px 0;
            font-size: 1rem;
        }

        .logout-btn {
            text-decoration: none;
            display: inline-block;
            margin-top: 18px;
            padding: 10px 22px;
            background: var(--primary);
            color: #000;
            border-radius: 20px;
            font-weight: bold;
            transition: 0.3s;
            box-shadow: 0 0 10px var(--primary);
        }

        .logout-btn:hover {
            background: var(--accent);
            box-shadow: 0 0 20px var(--accent),
                        0 0 30px var(--accent);
        }

        footer {
            margin-top: 50px;
            text-align: center;
            background: #1a1a2e;
            padding: 20px;
            color: #b0b8c1;
        }

    </style>
</head>
<body>

<header>
    <nav class="navbar">
        <div class="logo">MathFusion</div>
        <ul class="nav-links">
            <li><a href="index.html" >Home</a></li>
            <li><a href="syllabus.html">Syllabus</a></li>
            <li><a href="rating.html">Ratings</a></li>
            <li><a href="profile.php" class="active">Student Profile</a></li>
            <li><a href="logout.php" style="color:red;">Logout</a></li>
        </ul>
    </nav>
</header>

<div class="profile-container">
    <div class="profile-card">
        <img src="https://cdn-icons-png.flaticon.com/512/149/149071.png">

        <h2><?php echo $user['fullname']; ?></h2>
        <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
        <p><strong>Year:</strong> <?php echo $user['year']; ?></p>
        <p><strong>Branch:</strong> <?php echo $user['branch']; ?></p>
        <p><strong>College:</strong> <?php echo $user['college']; ?></p>
        <p><strong>City:</strong> <?php echo $user['city']; ?></p>
       

        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<footer>
    <p>&copy; 2025 MathFusion | All Rights Reserved</p>
</footer>

</body>
</html>
