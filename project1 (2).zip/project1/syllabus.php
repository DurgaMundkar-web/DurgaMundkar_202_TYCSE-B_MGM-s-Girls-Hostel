<?php
session_start();
if(!isset($_SESSION['users_email'])){
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Syllabus | MathFusion</title>
    <link rel="stylesheet" href="syllabus.css">
</head>
<body>

<header>
    <nav class="navbar">
        <div class="logo">MathFusion</div>
        <ul class="nav-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="logout.php">Logout</a></li>
            <li><a href="syllabus.php" class="active">Syllabus</a></li>
            <li><a href="rating.php">Ratings</a></li>
            <li><a href="profile.php">Student Profile</a></li>
        </ul>
    </nav>
</header>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>📚 MathFusion</h2>

    <!-- M1 -->
    <button class="dropdown-btn">M1 - Applied Mathematics I ▾</button>
    <div class="dropdown-container">
        <button class="sub-btn">Unit 1 : Matrix ▾</button>
        <div class="sub-container">
            <a href="matrixnote.html">Notes</a>
            <a href="matrixpyq.html">PYQs</a>
            <a href="matrixmcq.html">MCQs</a>
        </div>

        <button class="sub-btn">Unit 2 : Linear Algebra ▾</button>
        <div class="sub-container">
            <a href="linearnotes.html">Notes</a>
            <a href="linearpyq.html">PYQs</a>
            <a href="linearmcq.html">MCQs</a>
        </div>

        <button class="sub-btn">Unit 3 : Partial Differentiation ▾</button>
        <div class="sub-container">
            <a href="partialnote.html">Notes</a>
            <a href="partialpyq.html">PYQs</a>
            <a href="partialmcq.html">MCQs</a>
        </div>
    </div>

    <!-- M2 -->
    <button class="dropdown-btn">M2 - Applied Mathematics II ▾</button>
    <div class="dropdown-container">
        <button class="sub-btn">Unit 1 : Integrals ▾</button>
        <div class="sub-container">
            <a href="integralnotes.html">Notes</a>
            <a href="integralpyq.html">PYQs</a>
            <a href="integralsmcq.html">MCQs</a>
        </div>

        <button class="sub-btn">Unit 2 : Differential Equation ▾</button>
        <div class="sub-container">
            <a href="differentialnotes.html">Notes</a>
            <a href="differentialpyq.html">PYQs</a>
            <a href="differentialmcq.html">MCQs</a>
        </div>

        <button class="sub-btn">Unit 3 : Calculus ▾</button>
        <div class="sub-container">
            <a href="calculusnotes.html">Notes</a>
            <a href="calculuspyq.html">PYQs</a>
            <a href="calculusmcq.html">MCQs</a>
        </div>

        <button class="sub-btn">Unit 4 : Fourier Series ▾</button>
        <div class="sub-container">
            <a href="fouriernotes.html">Notes</a>
            <a href="fourierpyq.html">PYQs</a>
            <a href="fouriermcq.html">MCQs</a>
        </div>
    </div>

    <!-- M3 -->
    <button class="dropdown-btn">M3 - Applied Mathematics III ▾</button>
    <div class="dropdown-container">
        <button class="sub-btn">Unit 1 : Probability ▾</button>
        <div class="sub-container">
            <a href="probabilitynotes.html">Notes</a>
            <a href="probabilitypyq.html">PYQs</a>
            <a href="probabilitymcq.html">MCQs</a>
        </div>

        <button class="sub-btn">Unit 2 : Vector ▾</button>
        <div class="sub-container">
            <a href="vectornote.html">Notes</a>
            <a href="vectorpyq.html">PYQs</a>
            <a href="vectormcq.html">MCQs</a>
        </div>

        <button class="sub-btn">Unit 3 : Laplace ▾</button>
        <div class="sub-container">
            <a href="laplacenote.html">Notes</a>
            <a href="laplacepyq.html">PYQs</a>
            <a href="laplacemcq.html">MCQs</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="content">
    <h1>MathFusion Syllabus</h1>
    <p>Select Module → Unit → Study Material.</p>

    <div class="syllabus-section">
        <h2>M1 - Applied Mathematics I</h2>
        <ul>
            <li><strong>Unit 1: Matrix</strong> - Matrix operations, Determinants, Rank, Inverse</li>
            <li><strong>Unit 2: Linear Algebra</strong> - Vector Spaces, Eigenvalues, Eigenvectors</li>
            <li><strong>Unit 3: Partial Differentiation</strong> - Functions of several variables, Chain rule, Maxima & Minima</li>
        </ul>
    </div>

    <div class="syllabus-section">
        <h2>M2 - Applied Mathematics II</h2>
        <ul>
            <li><strong>Unit 1: Integrals</strong> - Definite & Indefinite Integrals, Applications</li>
            <li><strong>Unit 2: Differential Equation</strong> - First & Second Order ODE, Solutions</li>
            <li><strong>Unit 3: Calculus</strong> - Series, Convergence, Differentiation Techniques</li>
            <li><strong>Unit 4: Fourier Series</strong> - Trigonometric Series, Fourier Coefficients</li>
        </ul>
    </div>

    <div class="syllabus-section">
        <h2>M3 - Applied Mathematics III</h2>
        <ul>
            <li><strong>Unit 1: Probability</strong> - Random Variables, Distributions, Expectation</li>
            <li><strong>Unit 2: Vector</strong> - Vector Algebra, Scalar & Vector Products</li>
            <li><strong>Unit 3: Laplace</strong> - Laplace Transform, Inverse Transform, Applications</li>
        </ul>
    </div>
</div>

<script>
let dropdown = document.getElementsByClassName("dropdown-btn");
for (let i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function () {
        this.classList.toggle("active");
        let content = this.nextElementSibling;
        content.style.display = content.style.display === "block" ? "none" : "block";
    });
}

let sub = document.getElementsByClassName("sub-btn");
for (let i = 0; i < sub.length; i++) {
    sub[i].addEventListener("click", function () {
        this.classList.toggle("active");
        let cont = this.nextElementSibling;
        cont.style.display = cont.style.display === "block" ? "none" : "block";
    });
}
</script>

</body>
</html>
