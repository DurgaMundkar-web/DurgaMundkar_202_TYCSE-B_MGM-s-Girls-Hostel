<?php
include 'dp.php';

$errors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Sanitize inputs
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $phone   = trim($_POST['phone']);
    $dob     = $_POST['dob'];
    $address = trim($_POST['address']);
    $course  = $_POST['course'];

    // ---------------- SERVER SIDE VALIDATION ----------------

    if (empty($name) || empty($email) || empty($phone) || empty($dob) || empty($address) || empty($course)) {
        $errors[] = "All fields are required.";
    }

    // Name validation (characters only)
    if (!preg_match("/^[A-Za-z ]+$/", $name)) {
        $errors[] = "Name must contain letters only.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        $errors[] = "Phone number must be exactly 10 digits.";
    }

    // Age validation (minimum 17)
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    $age = $today->diff($birthDate)->y;

    if ($age < 17) {
        $errors[] = "You must be at least 17 years old.";
    }

    // ---------------- INSERT DATA ----------------
    if (empty($errors)) {

        $sql = "INSERT INTO hostel_students (name, email, phone, dob, address, course)
                VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $name, $email, $phone, $dob, $address, $course);

        if ($stmt->execute()) {
            echo "<script>
                    alert('Registration Successful!');
                    window.location.href = 'registration_success.html';
                  </script>";
            exit();
        } else {
            echo "<script>
                    alert('Registration Failed. Please try again.');
                    window.location.href = 'register.php';
                  </script>";
            exit();
        }
    } else {
        echo "<script>alert('" . implode("\\n", $errors) . "');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hostel Registration Form</title>

<style>
body {
  font-family: Arial, sans-serif;
}
.container {
  width: 50%;
  margin: 80px auto;
  padding: 50px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
label {
  font-weight: bold;
}
input, textarea, select {
  width: 100%;
  padding: 8px;
  margin-bottom: 15px;
}
input[type="submit"], input[type="reset"] {
  width: 48%;
}
</style>
</head>

<body>

<div class="container">
<h2>Hostel Registration Form</h2>

<form method="post" onsubmit="return validateForm()">

<label>Full Name</label>
<input type="text" id="name" name="name" required>

<label>Email</label>
<input type="email" id="email" name="email" required>

<label>Phone</label>
<input type="tel" id="phone" name="phone" required>

<label>Date of Birth</label>
<input type="date" id="dob" name="dob" required>

<label>Address</label>
<textarea id="address" name="address" required></textarea>

<label>Course</label>
<select id="course" name="course" required>
  <option value="">Select Course</option>
  <option value="BTech">BTech</option>
  <option value="BCS">BCS</option>
  <option value="BCA">BCA</option>
</select>

<input type="submit" value="Submit">
<input type="reset" value="Reset">

</form>
</div>

<script>
function validateForm() {

  const namePattern = /^[A-Za-z ]+$/;
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phonePattern = /^[0-9]{10}$/;

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const dob = document.getElementById("dob").value;

  if (!namePattern.test(name)) {
    alert("Name must contain letters only.");
    return false;
  }

  if (!emailPattern.test(email)) {
    alert("Enter a valid email address.");
    return false;
  }

  if (!phonePattern.test(phone)) {
    alert("Phone number must be 10 digits.");
    return false;
  }

  const birthDate = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();

  if (age < 17) {
    alert("You must be at least 17 years old.");
    return false;
  }

  return true;
}
</script>

</body>
</html>
