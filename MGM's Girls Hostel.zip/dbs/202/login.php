<?php
session_start();
include 'dp.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // ✅ Sanitize input
    $username = trim(htmlspecialchars($_POST['username']));
    $password = trim($_POST['password']);

    // ✅ Server-side validation
    if (empty($username) || empty($password)) {
        echo "<script>alert('All fields are required'); window.location='login.php';</script>";
        exit();
    }

    if (strlen($password) < 6) {
        echo "<script>alert('Password must be at least 6 characters long'); window.location='login.php';</script>";
        exit();
    }

    // ✅ Check user exists (email or username)
    $sql = "SELECT * FROM users WHERE email=? OR username=?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        echo "<script>alert('Database error'); window.location='login.php';</script>";
        exit();
    }

    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // ✅ Verify password
        if (password_verify($password, $row['password'])) {

            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['email'] = $row['email'];

            header("Location: dashboard.php"); 
            exit();
        } else {
            echo "<script>alert('Incorrect password'); window.location='login.php';</script>";
        }

    } else {
        echo "<script>alert('User not found'); window.location='login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hostel Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: 'Poppins', sans-serif;
          height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
        }

        body::before {
          content: "";
          position: fixed;
          top: 0;
          left: 0;
          height: 5px;
          width: 100%;
          background: linear-gradient(90deg, #6a11cb, #2575fc);
          animation: moveBar 3s linear infinite;
        }

        @keyframes moveBar {
          0% { background-position: 0% 50%; }
          100% { background-position: 100% 50%; }
        }

        .login-container {
          background: white;
          padding: 40px 30px;
          border-radius: 15px;
          box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
          width: 100%;
          max-width: 400px;
          animation: fadeIn 1s ease;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-30px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .login-form h1 {
          text-align: center;
          color: #333;
          margin-bottom: 40px;
        }

        .form-group {
          margin-bottom: 20px;
        }

        .form-group label {
          display: block;
          margin-bottom: 8px;
          font-weight: 600;
          color: #333;
        }

        input[type="text"],
        input[type="password"] {
          width: 100%;
          padding: 10px;
          border: 2px solid #ddd;
          border-radius: 8px;
          transition: border-color 0.4s, box-shadow 0.4s;
        }

        input:focus {
          border-color: #6a11cb;
          box-shadow: 0 0 5px rgba(106, 17, 203, 0.4);
          outline: none;
        }

        button[type="submit"] {
          width: 100%;
          padding: 12px;
          background: linear-gradient(to right, #6a11cb, #2575fc);
          color: #fff;
          border: none;
          border-radius: 8px;
          font-size: 16px;
          cursor: pointer;
          transition: transform 0.3s ease;
        }

        button[type="submit"]:hover {
          transform: scale(1.05);
        }

        .register-link {
          margin-top: 20px;
          text-align: center;
          font-size: 14px;
        }

        .register-link a {
          color: #6a11cb;
          text-decoration: none;
          font-weight: bold;
        }

        .register-link a:hover {
          text-decoration: underline;
        }
    </style>
</head>

<body>

<div class="login-container">
    <form class="login-form" method="POST" action="login.php">
        <h1>Login to Your Account</h1>

        <div class="form-group">
            <label>Email or Username</label>
            <input type="text" id="username" name="username" placeholder="Enter email or username" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" id="password" name="password" placeholder="Enter your password" required>
        </div>

        <button type="submit">Login</button>

        <p class="register-link">
            Don't have an account? <a href="register.php">Register here</a>
        </p>
    </form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector(".login-form");

  form.addEventListener("submit", function (e) {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (username === "" || password === "") {
      e.preventDefault();
      alert("Both username and password are required.");
      return;
    }

    if (username.includes("@")) {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(username)) {
        e.preventDefault();
        alert("Invalid email format.");
        return;
      }
    }

    if (password.length < 6) {
      e.preventDefault();
      alert("Password must be at least 6 characters long.");
    }
  });
});
</script>

</body>
</html>
