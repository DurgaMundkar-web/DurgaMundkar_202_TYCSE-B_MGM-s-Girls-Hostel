const form = document.getElementById("reviewForm");
const reviewText = document.getElementById("reviewText");
const reviewsDiv = document.getElementById("reviews");

// ✅ Page उघडताच सगळे saved reviews load होतील
window.onload = function () {
  const savedReviews = JSON.parse(localStorage.getItem("reviews")) || [];
  savedReviews.forEach((review) => {
    addReviewToPage(review.rating, review.text);
  });
};

// ✅ Review Submit
form.addEventListener("submit", function (e) {
  e.preventDefault();

  const rating = document.querySelector('input[name="rating"]:checked');
  if (!rating) {
    alert("Please select rating!");
    return;
  }

  const ratingValue = rating.value;
  const reviewMessage = reviewText.value.trim();

  if (reviewMessage === "") {
    alert("Please write review!");
    return;
  }

  addReviewToPage(ratingValue, reviewMessage);
  saveReview(ratingValue, reviewMessage);

  form.reset();
  alert("✅ Review Saved Permanently!");
});

// ✅ Review Design + UI
function addReviewToPage(ratingValue, reviewMessage) {
  let emoji = "😐";
  if (ratingValue == 5) emoji = "😍";
  else if (ratingValue == 4) emoji = "😊";
  else if (ratingValue == 3) emoji = "😐";
  else if (ratingValue == 2) emoji = "😕";
  else if (ratingValue == 1) emoji = "😢";

  const newReview = document.createElement("div");
  newReview.classList.add("review-card");

  newReview.innerHTML = `
    <h4>⭐ ${ratingValue} Stars - ${emoji}</h4>
    <p>"${reviewMessage}"</p>
  `;

  reviewsDiv.prepend(newReview);
}

// ✅ Browser मध्ये permanently save
function saveReview(rating, text) {
  const reviews = JSON.parse(localStorage.getItem("reviews")) || [];
  reviews.push({ rating, text });
  localStorage.setItem("reviews", JSON.stringify(reviews));
}
