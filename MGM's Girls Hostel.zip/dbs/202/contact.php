<?php
include 'dp.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $fullname = trim($_POST['fullname']);
    $email    = trim($_POST['email']);
    $phone    = trim($_POST['phone']);
    $message  = trim($_POST['message']);

    // Simple validation
    if (!empty($fullname) && !empty($email) && !empty($phone) && !empty($message)) {

        $sql = "INSERT INTO contact_messages (fullname, email, phone, message)
                VALUES (?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $fullname, $email, $phone, $message);

        if ($stmt->execute()) {
            echo "<script>
                    alert('Thank you! Your message has been sent successfully.');
                    window.location.href='contact.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Database Error. Please try again.');
                    window.location.href='contact.php';
                  </script>";
        }

        $stmt->close();
    } else {
        echo "<script>
                alert('All fields are required!');
                window.location.href='contact.php';
              </script>";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Us - Mgm's Girls Hostel</title>
  <link rel="stylesheet" href="contact.css"/>
</head>
<body>

  <section class="contact-section">
    <div class="container">
      <h2>Contact Us</h2>
      <p class="sub-text">We'd love to hear from you. Get in touch using the form below.</p>
      
      <div class="contact-wrapper">

        <!-- ✅ CORRECT CONTACT FORM -->
        <form class="contact-form" action="contact.php" method="POST">
          <input type="text" name="fullname" placeholder="Full Name" required />
          <input type="email" name="email" placeholder="Email Address" required />
          <input type="tel" name="phone" placeholder="Phone Number" required />
          <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
          <button type="submit">Send Message</button>
        </form>

        <!-- ✅ CONTACT INFO -->
        <div class="contact-info">
          <h3>Hostel Address</h3>
          <p>
            Mgm's Girls Hostel<br>
            Mgm's College Of Engineering<br>
            Nanded, Maharashtra
          </p>

          <h3>Email</h3>
          <p>contact@Mgmhostel.in</p>

          <div class="social-links">
            <a href="#"><img src="https://img.icons8.com/ios-filled/24/4a148c/facebook.png" alt="Facebook" /></a>
            <a href="#"><img src="https://img.icons8.com/ios-filled/24/4a148c/instagram-new.png" alt="Instagram" /></a>
            <a href="#"><img src="https://img.icons8.com/ios-filled/24/4a148c/email.png" alt="Email" /></a>
          </div>
        </div>

      </div>
    </div>
  </section>

</body>
</html>
